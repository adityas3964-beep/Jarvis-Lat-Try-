# J.A.R.V.I.S — Kotlin Android Voice Assistant

This is a native Kotlin Android project. The main screen has been redesigned around the supplied J.A.R.V.I.S references: dark navy background, cyan HUD accents, radar-style center graphic, status cards, and clear start/stop and setup controls.

## Build an APK with GitHub Actions

1. Create a GitHub repository and upload the **contents** of this folder, including `.github/workflows/build.yml`.
2. Open **Actions → Build APK** and run the workflow (or push a commit to trigger it).
3. Download the `jarvis-apk` artifact and extract `app-debug.apk`.
4. Install the APK on your Android phone.

The workflow downloads the Vosk **small English** model into `app/src/main/assets/model` before building. The model is intentionally not included in this source ZIP because it is a separate large asset. The current wake-word model is English; Hindi command recognition depends on the Android speech-recognition service and its installed language support.

## First launch

1. Grant microphone permission.
2. Tap **START JARVIS** and allow notifications if Android asks.
3. If prompted, enable Jarvis in Android Accessibility settings for supported accessibility actions.
4. Say “Jarvis” to trigger the command listener. Tap **STOP ASSISTANT** to stop the foreground service.

## Notes and limitations

- This project has not been verified on a physical device as part of this ZIP preparation.
- Background microphone behavior depends on Android version, permissions, and manufacturer battery restrictions.
- The “display over other apps” and accessibility settings are optional for features that need them; Android still requires the user to enable these settings manually.
- Calls require the appropriate permission and user/device support. Review requested permissions before installing.
