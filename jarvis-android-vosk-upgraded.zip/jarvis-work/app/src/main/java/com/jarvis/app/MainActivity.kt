package com.jarvis.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.Color

class MainActivity : Activity() {
    private val cyan = Color.rgb(0, 220, 255)
    private val blue = Color.rgb(35, 120, 255)
    private val bg = Color.rgb(7, 12, 22)
    private val panel = Color.rgb(13, 24, 39)
    private lateinit var status: TextView
    private lateinit var startButton: TextView
    private lateinit var langButton: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0
        val prefs = getSharedPreferences("jarvis", MODE_PRIVATE)

        val scroll = ScrollView(this).apply { setBackgroundColor(bg); clipToPadding = false }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(28))
        }
        scroll.addView(root)
        setContentView(scroll)

        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val brand = TextView(this).apply {
            text = "J.A.R.V.I.S"; textSize = 27f; letterSpacing = .12f
            setTextColor(cyan); typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            glow(cyan)
        }
        header.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(TextView(this).apply {
            text = "● SYSTEM"; textSize = 11f; letterSpacing = .08f; setTextColor(cyan)
            background = rounded(panel, cyan, 1, 16); setPadding(dp(12), dp(8), dp(12), dp(8))
        })
        root.addView(header)
        root.addView(TextView(this).apply {
            text = "JUST A RATHER VERY INTELLIGENT SYSTEM"; textSize = 9f; letterSpacing = .14f
            setTextColor(Color.rgb(105, 135, 158)); setPadding(0, dp(3), 0, dp(18))
        })

        val time = TextView(this).apply {
            text = "PERSONAL ASSISTANT  •  OFFLINE WAKE WORD"; textSize = 11f; letterSpacing = .08f
            setTextColor(Color.rgb(145, 185, 205)); gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(6))
        }
        root.addView(time)
        root.addView(RadarView().apply { layoutParams = LinearLayout.LayoutParams(-1, dp(190)) })
        status = TextView(this).apply {
            text = "SYSTEM STANDBY"; textSize = 15f; letterSpacing = .16f; gravity = Gravity.CENTER
            setTextColor(cyan); setPadding(0, dp(2), 0, dp(18))
        }
        root.addView(status)

        val info = card()
        info.addView(sectionTitle("SYSTEM STATUS"))
        info.addView(metric("VOICE ENGINE", "Vosk wake-word listener"))
        info.addView(metric("COMMAND MODE", "Hindi / English speech"))
        info.addView(metric("PRIVACY", "Wake word runs offline*"))
        root.addView(info)

        val controls = card()
        controls.addView(sectionTitle("CONTROL PANEL"))
        startButton = actionButton("▶   START JARVIS", true) { startJarvis() }
        controls.addView(startButton, matchWrap())
        val stop = actionButton("■   STOP ASSISTANT", false) {
            stopService(Intent(this, JarvisService::class.java))
            status.text = "SYSTEM STOPPED"
            status.setTextColor(Color.rgb(255, 105, 105))
            Toast.makeText(this, "Jarvis stopped", Toast.LENGTH_SHORT).show()
        }
        val stopParams = matchWrap(); stopParams.topMargin = dp(10)
        controls.addView(stop, stopParams)
        langButton = actionButton("", false) {
            val next = if (prefs.getString("lang", "hi-IN") == "hi-IN") "en-IN" else "hi-IN"
            prefs.edit().putString("lang", next).apply(); updateLanguage(prefs.getString("lang", "hi-IN") ?: "hi-IN")
        }
        val langParams = matchWrap(); langParams.topMargin = dp(10)
        controls.addView(langButton, langParams)
        updateLanguage(prefs.getString("lang", "hi-IN") ?: "hi-IN")
        root.addView(controls)

        val setup = card()
        setup.addView(sectionTitle("SETUP & PERMISSIONS"))
        setup.addView(actionButton("01   GRANT PERMISSIONS", false) { requestNeededPermissions() }, matchWrap())
        setup.addView(actionButton("02   DISPLAY OVER OTHER APPS", false) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }, matchWrap().apply { topMargin = dp(8) })
        setup.addView(actionButton("03   ACCESSIBILITY SERVICE", false) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }, matchWrap().apply { topMargin = dp(8) })
        setup.addView(actionButton("04   BATTERY OPTIMIZATION", false) {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }, matchWrap().apply { topMargin = dp(8) })
        root.addView(setup)

        root.addView(TextView(this).apply {
            text = "*Speech commands may use Android's speech recognition service. Keep the app open for setup."
            textSize = 10f; setTextColor(Color.rgb(100, 125, 145)); gravity = Gravity.CENTER
            setPadding(dp(10), dp(10), dp(10), dp(6))
        })
    }

    private fun startJarvis() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestNeededPermissions(); Toast.makeText(this, "Grant microphone permission, then tap Start again", Toast.LENGTH_LONG).show(); return
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
        }
        try {
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(Intent(this, JarvisService::class.java))
            else startService(Intent(this, JarvisService::class.java))
            status.text = "INITIALIZING • SAY ‘JARVIS’"
            status.setTextColor(cyan)
            Toast.makeText(this, "Jarvis starting. First model load may take a moment.", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            status.text = "START FAILED • CHECK PERMISSIONS"
            Toast.makeText(this, "Could not start Jarvis: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun requestNeededPermissions() {
        val permissions = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED ||
            (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)) {
            requestPermissions(permissions.toTypedArray(), 1)
        } else Toast.makeText(this, "Basic permissions already granted", Toast.LENGTH_SHORT).show()
    }

    private fun updateLanguage(lang: String) { langButton.text = "◉   SPEECH LANGUAGE: " + if (lang == "hi-IN") "HINDI" else "ENGLISH (INDIA)" }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2)
    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(15), dp(15), dp(15), dp(15))
        background = rounded(panel, Color.rgb(20, 68, 95), 1, 18)
        val p = LinearLayout.LayoutParams(-1, -2); p.bottomMargin = dp(14); layoutParams = p
    }
    private fun sectionTitle(t: String) = TextView(this).apply {
        text = t; textSize = 11f; letterSpacing = .14f; setTextColor(cyan)
        setPadding(0, 0, 0, dp(12)); typeface = Typeface.DEFAULT_BOLD
    }
    private fun metric(label: String, value: String) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(5), 0, dp(5))
        addView(TextView(this@MainActivity).apply { text = label; textSize = 10f; letterSpacing = .04f; setTextColor(Color.rgb(100, 160, 185)) }, LinearLayout.LayoutParams(dp(125), -2))
        addView(TextView(this@MainActivity).apply { text = value; textSize = 12f; setTextColor(Color.rgb(215, 235, 245)) })
    }
    private fun actionButton(textValue: String, primary: Boolean, onClick: () -> Unit): TextView = TextView(this).apply {
        text = textValue; textSize = 12f; letterSpacing = .04f; gravity = Gravity.CENTER
        setTextColor(if (primary) Color.BLACK else Color.rgb(190, 225, 240)); typeface = Typeface.DEFAULT_BOLD
        setPadding(dp(12), dp(15), dp(12), dp(15))
        background = if (primary) rounded(GradientDrawable.Orientation.LEFT_RIGHT, cyan, blue, 2, 12) else rounded(Color.rgb(8, 18, 31), Color.rgb(26, 91, 122), 1, 12)
        setOnClickListener { onClick() }
    }
    private fun rounded(color: Int, stroke: Int, width: Int, radius: Int) = GradientDrawable().apply {
        setColor(color); setCornerRadius(dp(radius).toFloat()); setStroke(dp(width), stroke)
    }
    private fun rounded(orientation: GradientDrawable.Orientation, c1: Int, c2: Int, width: Int, radius: Int) = GradientDrawable(orientation, intArrayOf(c1, c2)).apply {
        setCornerRadius(dp(radius).toFloat()); setStroke(dp(width), c1)
    }
    private fun TextView.glow(color: Int) { paint.setShadowLayer(12f, 0f, 0f, color) }

    private inner class RadarView : View(this@MainActivity) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val cx = width / 2f; val cy = height / 2f; val r = dp(65).toFloat()
            p.style = Paint.Style.STROKE; p.strokeWidth = dp(1.4f.toInt()).toFloat(); p.color = cyan; p.alpha = 180
            canvas.drawCircle(cx, cy, r, p); canvas.drawCircle(cx, cy, r * .72f, p); canvas.drawCircle(cx, cy, r * .35f, p)
            p.alpha = 70; canvas.drawLine(cx - r, cy, cx + r, cy, p); canvas.drawLine(cx, cy - r, cx, cy + r, p)
            p.style = Paint.Style.FILL; p.alpha = 255; p.color = cyan; p.setShadowLayer(dp(10).toFloat(), 0f, 0f, cyan)
            canvas.drawCircle(cx, cy, dp(4).toFloat(), p); p.clearShadowLayer()
            p.style = Paint.Style.STROKE; p.strokeWidth = dp(3).toFloat(); p.color = blue
            canvas.drawArc(RectF(cx-r, cy-r, cx+r, cy+r), -90f, 245f, false, p)
        }
    }
}
